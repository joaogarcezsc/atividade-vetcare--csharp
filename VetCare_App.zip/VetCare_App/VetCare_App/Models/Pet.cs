﻿using System;
using System.Collections.Generic;

namespace VetCare_App.Models;

public partial class Pet
{
    public int Id { get; set; }

    public string Nome { get; set; } = null!;

    public string Raca { get; set; } = null!;

    public int Idade { get; set; }

    public DateOnly Nascimento { get; set; }

    public int? TutorId { get; set; }

    public virtual ICollection<Agendamento> Agendamentos { get; set; } = new List<Agendamento>();

    public virtual Tutor? Tutor { get; set; }
}
