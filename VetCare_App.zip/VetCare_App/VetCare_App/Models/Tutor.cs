﻿using System;
using System.Collections.Generic;

namespace VetCare_App.Models;

public partial class Tutor
{
    public int Id { get; set; }

    public string Nome { get; set; } = null!;

    public string Cpf { get; set; } = null!;

    public int Telefone { get; set; }

    public string Email { get; set; } = null!;

    public virtual ICollection<Pet> Pets { get; set; } = new List<Pet>();
}
