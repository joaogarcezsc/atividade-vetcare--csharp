﻿using System;
using System.Collections.Generic;

namespace VetCare_App.Models;

public partial class Agendamento
{
    public int Id { get; set; }

    public DateTime Datahora { get; set; }

    public string Motivo { get; set; } = null!;

    public int? PetId { get; set; }

    public virtual Pet? Pet { get; set; }
}
