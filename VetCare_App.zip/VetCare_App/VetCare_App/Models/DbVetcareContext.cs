﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace VetCare_App.Models;

public partial class DbVetcareContext : DbContext
{
    public DbVetcareContext()
    {
    }

    public DbVetcareContext(DbContextOptions<DbVetcareContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Agendamento> Agendamentos { get; set; }

    public virtual DbSet<Pet> Pets { get; set; }

    public virtual DbSet<Tutor> Tutors { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=ConexaoSqlServer");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Agendamento>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__agendame__3213E83F3C455DEA");

            entity.ToTable("agendamento");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Datahora)
                .HasColumnType("datetime")
                .HasColumnName("datahora");
            entity.Property(e => e.Motivo)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("motivo");
            entity.Property(e => e.PetId).HasColumnName("petId");

            entity.HasOne(d => d.Pet).WithMany(p => p.Agendamentos)
                .HasForeignKey(d => d.PetId)
                .HasConstraintName("FK__agendamen__petId__3B75D760");
        });

        modelBuilder.Entity<Pet>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__pet__3213E83FA93DD41E");

            entity.ToTable("pet");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Idade).HasColumnName("idade");
            entity.Property(e => e.Nascimento).HasColumnName("nascimento");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nome");
            entity.Property(e => e.Raca)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("raca");
            entity.Property(e => e.TutorId).HasColumnName("tutorId");

            entity.HasOne(d => d.Tutor).WithMany(p => p.Pets)
                .HasForeignKey(d => d.TutorId)
                .HasConstraintName("FK__pet__tutorId__38996AB5");
        });

        modelBuilder.Entity<Tutor>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__tutor__3213E83F4540D2E2");

            entity.ToTable("tutor");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Cpf)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("cpf");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nome");
            entity.Property(e => e.Telefone).HasColumnName("telefone");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
